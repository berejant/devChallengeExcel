package contracts

type CellList map[string]*Cell
