package contracts

type CellValuesGetter func(cellIds []string) []*string
