package contracts

type ExpressionsMap map[string]*string
